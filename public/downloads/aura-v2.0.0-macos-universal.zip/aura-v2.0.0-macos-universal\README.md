# AURA 2.0 SDK

Welcome to AURA 2.0!

To install, add the `bin` directory to your PATH.

```bash
export PATH="/path/to/aura/bin:$PATH"
```
